package com.example.deepanshuarora.asgnmnt3_mobcom;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

    public static final String MY_PREFS_NAME = "MyPrefsFile";
    //private SharedPreferences.Editor editor = pref.edit();
    Context mcontext;
    private SharedPreferences pref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mcontext = this;
        pref = mcontext.getSharedPreferences(MY_PREFS_NAME, Context.MODE_PRIVATE);
    }


    public void OnclickSetPref(View view){
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("MyName", "Abhishek");
        editor.putInt("MyAge", 21);
        editor.commit();
    }
    public void OnclickGetPref(View view) {
        // If value for key not exist then return second/default parameter value
            String name = pref.getString("MyName", "Error");//"Error" is default parameter
            int age = pref.getInt("MyAge", 0); //0 is the default parameter
            TextView mytv = (TextView)findViewById(R.id.tv);
            mytv.setText("MyName              " + name + "\nMyAge                  " + age);

    }


}

