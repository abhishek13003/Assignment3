package com.example.deepanshuarora.asgnmnt3_mobcom;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void Onclickb1(View view){
        Intent myIntent = new Intent(HomeActivity.this, MainActivity.class);
        HomeActivity.this.startActivity(myIntent);
    }
    public void Onclickb2(View view){
        Intent myIntent = new Intent(HomeActivity.this, External_Internal_Activity.class);
        HomeActivity.this.startActivity(myIntent);
    }
    public void Onclickb3(View view){
        Intent myIntent = new Intent(HomeActivity.this, ThirdActivity.class);
        HomeActivity.this.startActivity(myIntent);
    }
}
