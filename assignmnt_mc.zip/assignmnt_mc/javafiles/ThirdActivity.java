package com.example.deepanshuarora.asgnmnt3_mobcom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

public class ThirdActivity extends AppCompatActivity {
    DB_Handler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        db = new DB_Handler(this);

        /**
         * CRUD Operations
         * */
        // Inserting Contacts
        Button ins = (Button)findViewById(R.id.addtodb);

        if (ins != null) {
            ins.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int allowed  = 0;
                    EditText editText1 = (EditText)findViewById(R.id.et1);
                    EditText editText2 = (EditText)findViewById(R.id.et2);
                    EditText editText3 = (EditText)findViewById(R.id.et3);

                    int rno = Integer.parseInt(editText1.getText().toString());
                    String nm = editText2.getText().toString();
                    String sem = editText3.getText().toString();




                    List<Entry> entries = db.getAllEntries();
                    for (Entry entry : entries) {
                        if(entry.getRollno() == rno){
                            Toast.makeText(ThirdActivity.this, "Duplicate Entry", Toast.LENGTH_SHORT).show();
                            allowed = -1;
                        }

                    }
                    if(allowed != -1)
                    {
                        db.addEntry(new Entry(rno, nm, sem));
                        Toast.makeText(ThirdActivity.this, "Entry Added Successfully", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
        Button Showdb = (Button)findViewById(R.id.show_mydb);
        if (Showdb != null) {
            Showdb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView showdb = (TextView) findViewById(R.id.fulldb);
                    // Log.d("Reading: ", "Reading all contacts..");
                    List<Entry> contacts = db.getAllEntries();
                    //showdb.append("RollNo           Name            CurrentSem\n");
                    for (Entry cn : contacts) {
                         showdb.append("\n" + "RollNo: "+cn.getRollno()+" ,Name: " + cn.getName() + " ,Semester: " + cn.getCurrentsem());
                        // Writing Contacts to log
                        //Log.d("ABCD", log);
                    }
                }
            });
        }

        //Log.d("Insert: ", "Inserting ..");
        //db.addEntry(new Entry(2013003, "Abhishek Chaudhary", "Sem 5"));
        //db.addEntry(new Entry(2013047, "karan", "Sem 7"));
        //db.addEntry(new Entry(2013097,"Shrey Chopra", "Sem 7"));
        //db.addEntry(new Entry(2013003,"Abhishek Chaudhary", "Sem 5"));


        // Reading all contacts
//        TextView showdb = (TextView)findViewById(R.id.fulldb);
//       // Log.d("Reading: ", "Reading all contacts..");
//        List<Entry> contacts = db.getAllEntries();
//        showdb.append("RollNo           Name            CurrentSem\n");
//        for (Entry cn : contacts) {
//            String log = cn.getRollno()+ "          " + cn.getName() + "          " + cn.getCurrentsem();
//            // Writing Contacts to log
//            //Log.d("ABCD", log);
//        }

        Button btnsearch = (Button)findViewById(R.id.srch_button);
        if (btnsearch != null) {
            btnsearch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText srch = (EditText)findViewById(R.id.search);
                    int rn = Integer.parseInt(srch.getText().toString());
                    Entry res = db.getEntry(rn);
                    // String log = "Id: "+res.getRollno()+" ,Name: " + res.getName() + " ,Phone: " + res.getCurrentsem();
                    // Writing Contacts to log
                    Toast.makeText(ThirdActivity.this, "Entry Found\nDetails: Name: "+ res.getName() + "," + res.getRollno() + ","+res.currentsem + " \n", Toast.LENGTH_SHORT).show();

                }
            });
        }

        Button btndel = (Button)findViewById(R.id.del_button);
        if (btndel != null) {
            btndel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText srch = (EditText)findViewById(R.id.delete);
                    int rn = Integer.parseInt(srch.getText().toString());
                    Entry res = db.getEntry(rn);
                    db.deleteEntry(res);
                    // String log = "Id: "+res.getRollno()+" ,Name: " + res.getName() + " ,Phone: " + res.getCurrentsem();
                    // Writing Contacts to log
                    Toast.makeText(ThirdActivity.this, " Entry Deleted", Toast.LENGTH_SHORT).show();

                }
            });
        }


        //Update
        Button upd = (Button)findViewById(R.id.update_in_db);

        if (upd != null) {
            upd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int allowed  = 0;
                    EditText editText4 = (EditText)findViewById(R.id.et4);
                    EditText editText5 = (EditText)findViewById(R.id.et5);
                    EditText editText6 = (EditText)findViewById(R.id.et6);

                    int rno = Integer.parseInt(editText4.getText().toString());
                    String nm = editText5.getText().toString();
                    String sem = editText6.getText().toString();




                    List<Entry> entries = db.getAllEntries();
                    for (Entry entry : entries) {
                        if(entry.getRollno() == rno){
                            Toast.makeText(ThirdActivity.this, "Duplicate Entry", Toast.LENGTH_SHORT).show();
                            allowed = -1;
                        }

                    }
                    if(allowed == -1)
                    {
                        db.updateEntry(new Entry(rno, nm, sem));
                        Toast.makeText(ThirdActivity.this, "Entry Updated Successfully", Toast.LENGTH_SHORT).show();

                    }
                    else {
                        Toast.makeText(ThirdActivity.this, "Entry Not Found", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
        //Log.d("ENTRY", log);
    }
}
