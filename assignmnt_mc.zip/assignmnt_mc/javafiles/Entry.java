package com.example.deepanshuarora.asgnmnt3_mobcom;

/**
 * Created by deepanshuarora on 02/10/16.
 */
public class Entry {
    int rollno;
    String name;
    String currentsem;


    public Entry(int rollno, String name, String currentsem) {
        this.rollno = rollno;
        this.name = name;
        this.currentsem = currentsem;
    }

    public Entry() {
    }

    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrentsem() {
        return currentsem;
    }

    public void setCurrentsem(String currentsem) {
        this.currentsem = currentsem;
    }
}
