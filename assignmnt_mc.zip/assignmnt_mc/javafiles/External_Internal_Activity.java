package com.example.deepanshuarora.asgnmnt3_mobcom;

import android.content.Context;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class External_Internal_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_external_internal);
    }

    //Working Fine
    //This File is stored in internal storage
    //File accessible only to your app(in this case as output stram has MODE_PRIVATE as a param) but user cannot access these files manually without root
    //This File will be deleted when user uninstalls the application
    public void WriteIntStorage(View view){
        String content = "Internal Storage Content";
        String fileName = "Internal_File";

        FileOutputStream outputStream = null;
        try {
            outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
            outputStream.write(content.getBytes());
            outputStream.close();
            Toast.makeText(this, "Internal Storage Done" + getFilesDir(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //This File is stored in external storage(SD card or permanent external partition in the permanent storage space)
    // It is accessible to the user even after user uninstalls the application or clears its data
    public void WriteExtStoragePublicFile(View view){
        String content = "External Storage Public File Content";
        File file;
        FileOutputStream outputStream;
        try {
            file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "External_Storage_PublicFile");
            outputStream = new FileOutputStream(file);
            outputStream.write(content.getBytes());
            outputStream.close();
            Toast.makeText(this, "Ext Public File Saved in " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //This File is stored in external storage
    // This File is deleted when user uninstalls the application as System deletes the app's external private directory
   //Working Fine
    public void WriteExtStoragePrivateFile(View view){
        String content = "External Storage Private File Content";
        //String fileName = "External_Storage_PrivateFile";

        File file;
        FileOutputStream outputStream;
        try {
            file = new File(getExternalFilesDir(null), "External_Storage_PrivateFile");
            outputStream = new FileOutputStream(file);
            outputStream.write(content.getBytes());
            outputStream.close();
            Toast.makeText(this, "Ext Private File Saved in " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
